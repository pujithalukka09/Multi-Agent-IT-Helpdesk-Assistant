# Multi-Agent IT Helpdesk Assistant

A beginner-friendly Python prototype based on the project report **“Agentic AI in Practice: Case Studies and a Prototype Project Report.”**

The application demonstrates a multi-agent IT helpdesk workflow:
- **Router/Triage Agent:** classifies the request and assigns urgency.
- **Knowledge Agent:** retrieves answers from a small local helpdesk knowledge base.
- **Account Agent:** provides safe account-support guidance; it does not modify real accounts.
- **Diagnostics Agent:** gives basic troubleshooting guidance; it does not access real devices.
- **Ticket Agent:** stores support tickets in SQLite.
- **Guardrails:** blocks selected unsafe data-exfiltration instructions and escalates urgent or human-requested cases.
- **Audit logging:** records classification, ticket creation, and blocked requests.

## 1. Requirements
- Python 3.10 or newer
- Internet connection for the first-time package installation

## 2. Run locally

Open a terminal in this project folder and run:

```bash
python -m venv .venv
```

Activate the environment:

**Windows PowerShell**
```powershell
.venv\Scripts\Activate.ps1
```

**Windows Command Prompt**
```cmd
.venv\Scripts\activate
```

**macOS/Linux**
```bash
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Start the application:

```bash
uvicorn app.main:app --reload
```

Open **http://127.0.0.1:8000** in your browser.

API documentation is available at **http://127.0.0.1:8000/docs**.

## 3. Try these sample requests

1. `How do I connect to the VPN?`
2. `I forgot my password and need help.`
3. `My printer is not working.`
4. `I need access to the design software.`
5. `This is urgent: I cannot work because the network is down.`
6. `Please connect me to a human technician.` (select the human-support checkbox)

## 4. Project structure

```text
Multi-Agent-IT-Helpdesk-Assistant/
├── app/
│   ├── __init__.py
│   ├── agents.py
│   ├── config.py
│   ├── database.py
│   └── main.py
├── data/                  # SQLite database is created automatically
├── .gitignore
├── README.md
└── requirements.txt
```

## 5. Important prototype limitations

This is a **working educational prototype**, not a production deployment and not a connected enterprise AI system. It uses simple rule-based routing and a local knowledge dictionary to demonstrate the architecture. It does not call an external LLM, reset real passwords, grant real software access, inspect devices, send email, or integrate with a real ticketing platform. The report describes these as future implementation/integration capabilities.

Do not enter real passwords, verification codes, confidential information, or personal data.

## 6. Upload to GitHub

1. Sign in at [GitHub](https://github.com/).
2. Select **New repository**.
3. Repository name: `Multi-Agent-IT-Helpdesk-Assistant`.
4. Choose **Public** or **Private**, then create the repository.
5. Extract this ZIP file on your computer.
6. Open the extracted project folder and upload its contents to the repository using **Add file → Upload files**.
7. Commit the files.

Alternatively, use Git:

```bash
git init
git add .
git commit -m "Add multi-agent IT helpdesk assistant prototype"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/Multi-Agent-IT-Helpdesk-Assistant.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

## 7. Suggested GitHub description

A Python-based multi-agent IT Helpdesk Assistant prototype featuring request routing, knowledge support, diagnostics guidance, ticket creation, human escalation, guardrails, and SQLite audit logging.
