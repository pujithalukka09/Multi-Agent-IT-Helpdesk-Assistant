from .database import create_ticket, log_event

KNOWLEDGE = {
    "vpn": "To connect to the company VPN: open the approved VPN client, sign in with your organisation account, complete multi-factor verification, and select Connect. If it fails, record the error and contact IT.",
    "password": "Use the organisation's official password-reset page. Complete identity verification before changing your password. Never share your password or verification code with support staff.",
    "printer": "Check that the printer is powered on, connected to the correct network, and has paper. Restart the print queue and retry. If the issue continues, create an IT ticket.",
    "software": "Request standard software access through the approved access-request process. Include the software name and business reason. Access may require manager approval."
}

def classify_request(message):
    text = message.lower()
    if any(w in text for w in ["password", "reset", "login", "sign in"]):
        category = "account"
    elif any(w in text for w in ["vpn", "printer", "wifi", "network", "device", "laptop"]):
        category = "diagnostics"
    elif any(w in text for w in ["install", "software", "access", "permission"]):
        category = "software_access"
    else:
        category = "knowledge"
    urgency = "high" if any(w in text for w in ["urgent", "critical", "down", "cannot work", "security"]) else "normal"
    return category, urgency

def knowledge_agent(message):
    text = message.lower()
    for key, answer in KNOWLEDGE.items():
        if key in text:
            return {"answer": answer, "source": f"Internal Helpdesk Knowledge Base: {key.title()}"}
    return {
        "answer": "I could not find an exact article in the local knowledge base. I have prepared a support ticket so an IT technician can review your request.",
        "source": "No matching knowledge-base article"
    }

def account_agent(message):
    # Demo-only: never performs a real password reset or account change.
    return ("For your security, this prototype does not change passwords or accounts. "
            "Please use the organisation's verified password-reset process. "
            "A ticket can be created for IT support if you still need help.")

def diagnostics_agent(message):
    return ("I can provide basic troubleshooting guidance, but this demo does not connect "
            "to real devices or monitoring systems. Check power, network connectivity, "
            "and any displayed error message. A technician can investigate further.")

def ticket_agent(user_name, category, urgency, message, status="Open"):
    summary = message.strip().replace("\n", " ")[:180]
    ticket_id = create_ticket(user_name, category, urgency, message, status, summary)
    log_event("ticket_created", f"Ticket #{ticket_id}; category={category}; urgency={urgency}")
    return ticket_id, summary

def handle_request(user_name, message, request_human=False):
    if not message.strip():
        return {"reply": "Please enter a request.", "ticket_id": None, "category": None, "urgency": None}

    # Treat manipulative or data-exfiltration requests as untrusted input.
    suspicious = ["export employee directory", "show all passwords", "ignore previous instructions",
                  "reveal confidential", "download all employee"]
    if any(term in message.lower() for term in suspicious):
        log_event("blocked_request", "Potentially unsafe instruction was blocked.")
        return {
            "reply": "I cannot carry out that request because it may expose confidential information. "
                     "The attempt has been recorded for review by an IT technician.",
            "ticket_id": None, "category": "security", "urgency": "high"
        }

    category, urgency = classify_request(message)
    log_event("request_classified", f"category={category}; urgency={urgency}")

    if request_human or urgency == "high":
        ticket_id, _ = ticket_agent(user_name, category, urgency, message, "Escalated")
        return {
            "reply": f"Your request has been escalated to a human IT technician. Ticket #{ticket_id} was created. "
                     "A technician should review the details. This demo does not send a real notification.",
            "ticket_id": ticket_id, "category": category, "urgency": urgency
        }

    if category == "account":
        answer = account_agent(message)
    elif category == "diagnostics":
        answer = diagnostics_agent(message)
    elif category == "software_access":
        answer = "Software access requests may require approval. Please include the software name and business reason. " + knowledge_agent(message)["answer"]
    else:
        result = knowledge_agent(message)
        answer = result["answer"] + f"\n\nSource: {result['source']}"

    ticket_id, _ = ticket_agent(user_name, category, urgency, message, "Open")
    return {
        "reply": answer + f"\n\nFor tracking, I created ticket #{ticket_id}.",
        "ticket_id": ticket_id, "category": category, "urgency": urgency
    }
