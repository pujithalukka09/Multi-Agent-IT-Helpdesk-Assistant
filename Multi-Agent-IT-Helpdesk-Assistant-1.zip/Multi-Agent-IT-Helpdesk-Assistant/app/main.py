from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from .database import init_db, get_tickets, get_logs
from .agents import handle_request

app = FastAPI(title="Multi-Agent IT Helpdesk Assistant", version="1.0.0")

@app.on_event("startup")
def startup():
    init_db()

class HelpdeskRequest(BaseModel):
    user_name: str = Field(default="Guest", max_length=80)
    message: str = Field(min_length=1, max_length=2000)
    request_human: bool = False

@app.get("/", response_class=HTMLResponse)
def home():
    return """
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>IT Helpdesk Assistant</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f6fb;margin:0;color:#1e293b}
main{max-width:850px;margin:35px auto;padding:24px}
.card{background:white;padding:24px;border-radius:16px;box-shadow:0 4px 18px #0f172a12;margin-bottom:18px}
h1{margin-top:0;color:#163a63}label{display:block;font-weight:bold;margin:12px 0 6px}
input,textarea{width:100%;box-sizing:border-box;padding:12px;border:1px solid #cbd5e1;border-radius:8px;font:inherit}
textarea{min-height:120px}button{margin-top:14px;background:#1769aa;color:white;border:0;border-radius:8px;padding:12px 18px;font-weight:bold;cursor:pointer}
button:hover{background:#125487}.result{white-space:pre-wrap;line-height:1.5;background:#f8fafc;padding:16px;border-radius:8px}
small{color:#64748b}.links a{margin-right:14px;color:#1769aa}
</style></head><body><main>
<div class="card"><h1>Multi-Agent IT Helpdesk Assistant</h1>
<p>Submit an IT issue. The router classifies it and sends it to a specialist support agent.</p>
<label>Your name</label><input id="name" value="Guest" maxlength="80">
<label>Describe your issue</label><textarea id="message" placeholder="Example: I cannot connect to the VPN..."></textarea>
<label><input type="checkbox" id="human" style="width:auto"> I want to speak to a human technician</label>
<button onclick="sendRequest()">Submit request</button>
<div id="result" class="result" style="display:none;margin-top:18px"></div>
</div>
<div class="card links"><b>Project tools</b><p><a href="/docs">API documentation</a><a href="/tickets">View tickets</a><a href="/audit">Audit logs</a></p>
<small>Educational prototype only. It does not connect to real company accounts, devices, or ticketing systems.</small></div>
</main><script>
async function sendRequest(){
 const message=document.getElementById('message').value.trim();
 const result=document.getElementById('result');
 if(!message){alert('Please describe your issue.');return;}
 result.style.display='block'; result.textContent='Processing your request...';
 try{
  const response=await fetch('/api/helpdesk',{method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({user_name:document.getElementById('name').value,message,request_human:document.getElementById('human').checked})});
  const data=await response.json();
  result.textContent=data.reply+'\n\nCategory: '+data.category+' | Urgency: '+data.urgency;
 }catch(e){result.textContent='Unable to contact the server. Please try again.';}
}
</script></body></html>
"""

@app.post("/api/helpdesk")
def ask_helpdesk(request: HelpdeskRequest):
    return handle_request(request.user_name, request.message, request.request_human)

@app.get("/tickets")
def tickets():
    return {"tickets": get_tickets()}

@app.get("/audit")
def audit():
    return {"audit_logs": get_logs()}

@app.get("/health")
def health():
    return {"status": "ok"}
