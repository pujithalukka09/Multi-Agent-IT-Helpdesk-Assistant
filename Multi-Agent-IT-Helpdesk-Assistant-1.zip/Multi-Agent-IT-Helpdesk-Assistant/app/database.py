import sqlite3
from .config import DB_PATH

def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_name TEXT NOT NULL,
                category TEXT NOT NULL,
                urgency TEXT NOT NULL,
                message TEXT NOT NULL,
                status TEXT NOT NULL,
                summary TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event TEXT NOT NULL,
                details TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

def create_ticket(user_name, category, urgency, message, status, summary):
    with connect() as conn:
        cur = conn.execute(
            "INSERT INTO tickets (user_name, category, urgency, message, status, summary) VALUES (?, ?, ?, ?, ?, ?)",
            (user_name, category, urgency, message, status, summary)
        )
        return cur.lastrowid

def log_event(event, details):
    with connect() as conn:
        conn.execute("INSERT INTO audit_logs (event, details) VALUES (?, ?)", (event, details))

def get_tickets():
    with connect() as conn:
        return [dict(row) for row in conn.execute("SELECT * FROM tickets ORDER BY id DESC").fetchall()]

def get_logs():
    with connect() as conn:
        return [dict(row) for row in conn.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 100").fetchall()]
